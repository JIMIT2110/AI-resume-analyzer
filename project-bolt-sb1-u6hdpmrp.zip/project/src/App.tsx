import React, { useState } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle, Award, Briefcase, GraduationCap } from 'lucide-react';

interface Analysis {
  skills: string[];
  experience: string[];
  education: string[];
  score: number;
  suggestions: string[];
}

function App() {
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && droppedFile.type === 'application/pdf') {
      setFile(droppedFile);
      analyzeResume(droppedFile);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
      analyzeResume(selectedFile);
    }
  };

  const analyzeResume = async (file: File) => {
    setIsAnalyzing(true);
    // Simulated analysis - in a real app, this would call an AI service
    setTimeout(() => {
      setAnalysis({
        skills: ['React', 'TypeScript', 'Node.js', 'Python', 'AWS'],
        experience: [
          'Senior Software Engineer at Tech Corp',
          'Full Stack Developer at StartupX',
        ],
        education: ['Master\'s in Computer Science', 'Bachelor\'s in Software Engineering'],
        score: 85,
        suggestions: [
          'Consider adding more quantifiable achievements',
          'Include relevant certifications',
          'Expand on leadership experiences',
        ],
      });
      setIsAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-8">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">AI Resume Analyzer</h1>
          <p className="text-lg text-gray-600">Upload your resume and get instant AI-powered insights</p>
        </header>

        <div 
          className={`border-4 border-dashed rounded-lg p-8 mb-8 text-center transition-colors
            ${isDragging ? 'border-indigo-400 bg-indigo-50' : 'border-gray-300 bg-white'}
            ${!file ? 'cursor-pointer' : ''}`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          {!file ? (
            <div>
              <Upload className="w-16 h-16 mx-auto mb-4 text-gray-400" />
              <p className="text-lg mb-2">Drag and drop your resume here</p>
              <p className="text-gray-500 mb-4">or</p>
              <label className="bg-indigo-600 text-white px-6 py-2 rounded-lg cursor-pointer hover:bg-indigo-700 transition-colors">
                Browse Files
                <input
                  type="file"
                  className="hidden"
                  accept=".pdf"
                  onChange={handleFileInput}
                />
              </label>
            </div>
          ) : (
            <div className="flex items-center justify-center space-x-3">
              <FileText className="text-indigo-600 w-6 h-6" />
              <span className="text-gray-700">{file.name}</span>
              {isAnalyzing && (
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-indigo-600 border-t-transparent"></div>
              )}
            </div>
          )}
        </div>

        {analysis && (
          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              <div className="bg-green-50 rounded-lg p-6">
                <div className="flex items-center mb-4">
                  <CheckCircle className="w-6 h-6 text-green-600 mr-2" />
                  <h2 className="text-xl font-semibold">Resume Score</h2>
                </div>
                <div className="text-4xl font-bold text-green-600">{analysis.score}%</div>
              </div>
              
              <div className="bg-amber-50 rounded-lg p-6">
                <div className="flex items-center mb-4">
                  <AlertCircle className="w-6 h-6 text-amber-600 mr-2" />
                  <h2 className="text-xl font-semibold">Suggestions</h2>
                </div>
                <ul className="space-y-2">
                  {analysis.suggestions.map((suggestion, index) => (
                    <li key={index} className="text-amber-700">• {suggestion}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <div className="flex items-center mb-4">
                  <Award className="w-6 h-6 text-indigo-600 mr-2" />
                  <h2 className="text-xl font-semibold">Key Skills</h2>
                </div>
                <div className="flex flex-wrap gap-2">
                  {analysis.skills.map((skill, index) => (
                    <span
                      key={index}
                      className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-sm"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center mb-4">
                  <Briefcase className="w-6 h-6 text-indigo-600 mr-2" />
                  <h2 className="text-xl font-semibold">Experience</h2>
                </div>
                <ul className="space-y-2">
                  {analysis.experience.map((exp, index) => (
                    <li key={index} className="text-gray-700">• {exp}</li>
                  ))}
                </ul>
              </div>

              <div>
                <div className="flex items-center mb-4">
                  <GraduationCap className="w-6 h-6 text-indigo-600 mr-2" />
                  <h2 className="text-xl font-semibold">Education</h2>
                </div>
                <ul className="space-y-2">
                  {analysis.education.map((edu, index) => (
                    <li key={index} className="text-gray-700">• {edu}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;